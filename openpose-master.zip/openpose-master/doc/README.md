The OpenPose documentation is available in 2 different formats, choose your preferred one!
- As a traditional website (recommended): [cmu-perceptual-computing-lab.github.io/openpose/web/html/doc/](https://cmu-perceptual-computing-lab.github.io/openpose/web/html/doc/).
- As markdown files: [github.com/CMU-Perceptual-Computing-Lab/openpose/tree/master/doc](https://github.com/CMU-Perceptual-Computing-Lab/openpose/tree/master/doc).
