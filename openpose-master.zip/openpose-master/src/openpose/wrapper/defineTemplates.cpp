#include <openpose/wrapper/headers.hpp>

namespace op
{
    template class OP_API WrapperT<BASE_DATUM>;
}
